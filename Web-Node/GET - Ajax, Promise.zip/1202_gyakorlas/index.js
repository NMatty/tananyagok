//const catUrl = 'https://cat-fact.herokuapp.com/facts';
const catUrl = 'https://api.thecatapi.com/v1/images/search';

//Ajax get - Szinkron
const getMethodAjax = (url) => {
    const request = new XMLHttpRequest();
    request.open('GET', url, false); // false => szinkron legyen a metódus
    try {
        request.send();
        if (request.status === 200) {
            //A státusz OK-e, vagyis sikeres volt a kérés
            return JSON.parse(request.response);
        } else {
            throw new Error(`Hiba: ${request.status}`);
        }
    } catch (error) {
        throw new Error(`Hálózati hiba történt: ${error.message}`);
    }
};

//Ajax get - Aszinkron
const getMethodAjaxAsync = (url) => {
    const request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.readyState === 4) {
            if (request.status === 200) {
                console.log(JSON.parse(request.responseText));
            } else {
                console.log('Hiba történt: ' + request.status);
            }
        }
    };
    request.open('GET', url, true);
    request.send();
};

//Ajax get aszinkron Promise
const getMethodAjaxAsyncPromise = (url) => {
    return new Promise((resolve, reject) => {
        const request = new XMLHttpRequest();
        request.open('GET', url, true);
        request.onload = () => {
            if (request.status === 200) {
                try {
                    const jsonData = JSON.parse(request.response);
                    resolve(jsonData);
                } catch (error) {
                    reject(Error('Nem sikerült a JSON parse: ' + error.message));
                }
            } else {
                reject(Error('Hiba: ' + request.status));
            }
        };
        request.onerror = () => {
            reject(Error('Hálózati hiba történt'));
        };
        request.send();
    });
};

//GET method - Fetch
const getMethodFetch = (url) => {
    return fetch(url)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Hiba: ' + response.status);
            }
            return response.json(); //A választ visszaadjuk json formátumban
        })
        .then((data) => {
            return data;
        })
        .catch((error) => {
            throw new Error('Hiba történt: ' + error.message);
        });
};

//GET method - Fetch - Promise
const getMethodFetchPromise = (url) => {
    return new Promise((resolve, reject) => {
        fetch(url)
            .then((response) => {
                if (!response.ok) {
                    reject('Hiba: ' + response.status);
                }
                return response.json();
            })
            .then((data) => {
                resolve(data);
            })
            .catch((error) => {
                reject('Hiba: ' + error);
            });
    });
};

const createImg = (src, width, height) => {
    const div = document.querySelector('.catImg');
    const img = document.createElement('img');
    img.src = src;
    img.width = width;
    img.height = height;
    div.appendChild(img);
};

// document.addEventListener('DOMContentLoaded', () => {
//     //!Ajax szinkron
//     // try {
//     //     const data = getMethodAjax(catUrl);
//     //     console.log('Cat facts Ajax - nincs promise: ', data);
//     //     createImg(data[0].url, data[0].width, data[0].height);
//     // } catch (error) {
//     //     console.log(error.message);
//     // }
//     //!Ajax aszinkron
//     // getMethodAjaxAsync(catUrl);
//     //!Ajax aszinkron promise
//     // getMethodAjaxAsyncPromise(catUrl)
//     //     .then((resolve) => console.log(resolve))
//     //     .catch((error) => console.log(error));
//     //!Fetch get - aszinkron
//     // getMethodFetch(catUrl)
//     //     .then((response) => {
//     //         console.log(response);
//     //     })
//     //     .catch((error) => {
//     //         console.log(error);
//     //     });
//     //!Fetch get - aszinkron Promise
//     // getMethodFetchPromise(catUrl)
//     //     .then((response) => {
//     //         console.log(response);
//     //     })
//     //     .catch((error) => {
//     //         console.log(error);
//     //     });
// });

// document.addEventListener('DOMContentLoaded', async () => {
//     try {
//         const data = await getMethodFetchPromise(catUrl);
//         console.log(data);
//         //Itt tudnánk tovább dolgozni a data-val
//     } catch (error) {
//         console.log(error);
//     }
// });

document.addEventListener('DOMContentLoaded', () => {
    (async () => {
        try {
            const data = await getMethodFetchPromise(catUrl);
            console.log(data);
            //Itt tudnánk tovább dolgozni a data-val
        } catch (error) {
            console.log(error);
        }
    })();

    // (async () => {})();
});
