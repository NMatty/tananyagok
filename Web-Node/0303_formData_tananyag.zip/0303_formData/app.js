//!Module-ok importálása
const express = require('express'); //?npm install express
const session = require('express-session'); //?npm install express-session
const path = require('path');

const app = express();
const router = express.Router();
//!SQL Queries importálása
const db = require(path.join(__dirname + '/sql/db-queries'));

//!Beállítások
const ip = '127.0.0.1';
const port = 3000;

//!Session beállítása:
app.use(
    session({
        secret: 'titkos_kulcs', //?Ezt generálni kell a későbbiekben
        resave: false,
        saveUninitialized: true
    })
);

//!Routing
//?Főoldal:
router.get('/', (request, response) => {
    response.sendFile(path.join(__dirname + '/public/html/index.html'));
});

app.use(express.json());
//!API végpont
app.get('/api/test', (request, response) => {
    response.status(200).send('/api/test működik.');
});

//!formData POST-hoz tartozó API végpont létrehozása. => formData kezelése esetén szükség van a következőre: const multer = require('multer'); - Ehhez pedig npm install segítségével telepíteni is kell a multer-t: npm install multer.
const multer = require('multer'); //!Jobb lenne a tetején elhelyezni, de így is működni fog. Ez kell nekünk a formData kezeléséhez!
const storage = multer.diskStorage({
    destination: './uploads', //!Annak meghatározása, hogyha fájl van hova legyen mentve
    filename: (request, file, callback) => {
        callback(null, file.originalname); //!A fájlt elmentjük azon a néven, amilyen néven fel lett töltve
    }
});
const upload = multer({ storage: storage });
app.post('/api/postFormData', upload.single('file'), (request, response) => {
    //!Ami az upload.single paraméterében megvan adva név, olyan néven fogja várni a fájlt. Ez a küldés részénél lesz nagyon fontos, mert hogyha nem ilyen néven küldjük a fájlt, akkor nemtudja a backend fogadni.
    //!A formData esetén is úgy KELL kezelni a post-ot, mintha egy fájlt töltenének fel, mivel a formData így érkezik a backend részére.
    //!A formData a postbody-ban érkezik a szerver irányába
    const formData = request.body;
    console.log('Felhasználónév: ', formData.userName);
    console.log('Jelszó: ', formData.userPassword);
    console.log('Születési dátum: ', formData.birthDate);
    response.status(200).json({
        message: 'formData küldése sikeres',
        formData: formData
    });
});

app.post('/api/postFile', upload.single('fileInput'), (request, response) => {
    console.log(request.body);
    console.log(request.file);
    if (!request.file) {
        response.status(500).json({
            message: 'Nem töltött fel fájlt!'
        });
    } else {
        response.status(200).json({
            message: '/api/postFormData kész.',
            formDataBody: request.body,
            file: request.file
        });
    }
});

app.post('/api/postFileAppend', upload.single('file'), (request, response) => {
    console.log(request.body);
    console.log(request.file);
    if (!request.file) {
        response.status(500).json({
            message: 'Nem töltött fel fájlt!'
        });
    } else {
        response.status(200).json({
            message: '/api/postFormData kész.',
            formDataBody: request.body,
            file: request.file
        });
    }
});
//!Szerver futtatása
app.use(express.static('public')); //?public mappa tartalmának betöltése az oldal működéséhez
app.use('/', router);
app.listen(port, ip, () => {
    console.log('Szerver elérhetősége: ' + ip + ':' + port);
});

//?Szerver futtatása terminalból: npm run start (Ehhez kell a következő: npm install nodemon --save-dev)
//?Szerver leállítása (MacBook és Windows): Control + C
//?Terminal ablak tartalmának törlése (MacBook): Command + K
