document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('confirmBtn').addEventListener('click', registerEvent);
    document.getElementById('fileUploadBtn').addEventListener('click', fileEvent);
    document.getElementById('fileUploadAppendBtn').addEventListener('click', fileAppendEvent);
});

const fileAppendEvent = () => {
    const formData = new FormData();
    const fileInput = document.getElementById('fileInput2');
    if (fileInput && fileInput.files.length > 0) {
        formData.append('file', fileInput.files[0]);
        fetch('/api/postFileAppend', {
            method: 'POST',
            body: formData
        })
            .then((response) => {
                if (!response.ok) {
                    console.log('Hiba: ' + response.status);
                }
                return response.json();
            })
            .then((data) => {
                console.log('Válasz: ', data);
            })
            .catch((error) => {
                console.error('Hiba: ' + error);
            });
    } else {
        alert('Nem választott fájlt...');
    }
};

const fileEvent = () => {
    const formData = new FormData(document.getElementById('formFile'));
    const fileInput = document.getElementById('fileInput');
    if (fileInput && fileInput.files.length > 0) {
        // formData.append('file', fileInput.files[0]); //!Így küldjük tovább a backend felé file néven a fájlt, amit feltöltöttünk
        // for (const [key, value] of formData) {
        //     console.log(key, value);
        // }
        fetch('/api/postFile', {
            method: 'POST',
            body: formData
            //*formData fetch esetén NEM SZABAD Content-Type-ot állítani, mivel azt automatikusan átállítja magának a fetch a body-ban kapott érték miatt.
        })
            .then((response) => {
                if (!response.ok) {
                    console.log('Hiba: ' + response.status);
                }
                return response.json();
            })
            .then((data) => {
                console.log('Válasz: ', data);
            })
            .catch((error) => {
                console.error('Hiba: ' + error);
            });
    } else {
        alert('Nem töltött fel fájlt!');
    }
};

const registerEvent = () => {
    const formData = new FormData(document.getElementById('formRegister'));

    fetch('/api/postFormData', {
        method: 'POST',
        body: formData
        //*formData fetch esetén NEM SZABAD Content-Type-ot állítani, mivel azt automatikusan átállítja magának a fetch a body-ban kapott érték miatt.
    })
        .then((response) => {
            if (!response.ok) {
                console.log('Hiba: ' + response.status);
            }
            return response.json();
        })
        .then((data) => {
            console.log('Válasz: ', data);
        })
        .catch((error) => {
            console.error('Hiba: ' + error);
        });
};

/*
const registerEvent = () => {
    const formData = new FormData(document.getElementById('formRegister')); //*A new FormData segítségével lesz létrehozva a formData. Paraméterbe várja a form-ot, innentől kezdve, amit a form tartalmaz azt a formData végig tudja iterálni kulcs-érték párok alapján. A "name" attribútum maga a key és a hozzátartozó érték lesz a value

    //*formData bejárása kulcs-érték párok és strukturális lebontás segítségével: (Strukturális lebontás esetén egy tömb elemeit látjuk el valamilyen névvel és az alapján hivatkozhatunk rá.)
    //let arr = ['Roland', 20];
    //const [name, age] of arr
    
    let counter = 0;
    for (const [key, value] of formData) {
        if (value === '') {
            counter++;
        }
        //console.log('Kulcs: ' + key + ' - Érték: ' + value);
    }
    if (counter > 0) {
        alert('Nem töltött ki minden mezőt.');
    }

    //*Van olyan eset, amikor a formData-hoz hozzászeretnénk adni egy új kulcs-érték párt, amelyet a form nem tartalmaz.
    formData.append('Kulcs', 'Érték');
    for (const [key, value] of formData) {
        console.log('Kulcs: ' + key + ' - Érték: ' + value);
    }
    //console.log(Array.from(formData));

    //*Van olyan eset, amikor a formData egy kulcs-érték párját törölni szeretnénk.
    formData.delete('Kulcs');
    for (const [key, value] of formData) {
        console.log('Kulcs: ' + key + ' - Érték: ' + value);
    }

    //*entries(): Ennek a függvénynek a segítségével is végig iterálható a formData
    for (const item of formData.entries()) {
        console.log('Kulcs: ' + item[0] + ' - Érték: ' + item[1]);
    }

    //*get(): Egy kulcshoz tartozó érték lekérése:
    console.log('Felhasználónév: ' + formData.get('userName'));

    //*has(): Lehet ellenőrizni ennek a segítségével, hogy egy kulcs létezik-e már a formData objektumban.
    console.log('Van felhasználónév kulcs? ' + formData.has('userName'));

    //*set(): A set metódus segítségével a formData egy adott kulcsához tartozó értéket lehet módosítani.
    formData.set('userName', 'Suhanyecz Alex');
};
*/
