-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2025. Ápr 09. 09:38
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `forma1`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `csapatok`
--

CREATE DATABASE IF NOT EXISTS forma1
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

USE forma1;

CREATE TABLE `csapatok` (
  `csapatazonosito` int(11) NOT NULL,
  `csapatnev` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `csapatok` (`csapatazonosito`, `csapatnev`) VALUES
(1, 'Red Bull Racing'),
(2, 'Ferrari'),
(3, 'Mercedes'),
(4, 'Alpine'),
(5, 'McLaren'),
(6, 'Aston Martin'),
(7, 'Alfa Romeo'),
(8, 'Haas'),
(9, 'AlphaTauri'),
(10, 'Williams');


-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `eredmenyek`
--

CREATE TABLE `eredmenyek` (
  `nagydij_azonosito` int(11) NOT NULL,
  `pilotazonosito` int(11) DEFAULT NULL,
  `nagydij_nev` varchar(100) DEFAULT NULL,
  `datum` date DEFAULT NULL,
  `start_pozicio` int(11) DEFAULT NULL,
  `cel_pozicio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `eredmenyek` (`nagydij_azonosito`, `pilotazonosito`, `nagydij_nev`, `datum`, `start_pozicio`, `cel_pozicio`) VALUES
(1, 1, 'Bahrain Nagydíj', '2023-03-05', 1, 1),
(2, 2, 'Bahrain Nagydíj', '2023-03-05', 2, 2),
(3, 11, 'Bahrain Nagydíj', '2023-03-05', 5, 3),
(4, 4, 'Bahrain Nagydíj', '2023-03-05', 4, 4),
(5, 5, 'Bahrain Nagydíj', '2023-03-05', 7, 5),
(6, 12, 'Bahrain Nagydíj', '2023-03-05', 8, 6),
(7, 6, 'Bahrain Nagydíj', '2023-03-05', 6, 7),
(8, 13, 'Bahrain Nagydíj', '2023-03-05', 10, 8),
(9, 7, 'Bahrain Nagydíj', '2023-03-05', 9, 9),
(10, 20, 'Bahrain Nagydíj', '2023-03-05', 15, 10),
(11, 18, 'Bahrain Nagydíj', '2023-03-05', 14, 11),
(12, 19, 'Bahrain Nagydíj', '2023-03-05', 16, 12),
(13, 15, 'Bahrain Nagydíj', '2023-03-05', 13, 13),
(14, 17, 'Bahrain Nagydíj', '2023-03-05', 18, 14),
(15, 16, 'Bahrain Nagydíj', '2023-03-05', 11, 15),
(16, 14, 'Bahrain Nagydíj', '2023-03-05', 12, 16),
(17, 9, 'Bahrain Nagydíj', '2023-03-05', 3, 17),
(18, 8, 'Bahrain Nagydíj', '2023-03-05', 19, 18),
(19, 3, 'Bahrain Nagydíj', '2023-03-05', 20, 19),
(20, 10, 'Bahrain Nagydíj', '2023-03-05', 17, 20),
(21, 2, 'Szaúd-arábiai Nagydíj', '2023-03-19', 1, 1),
(22, 1, 'Szaúd-arábiai Nagydíj', '2023-03-19', 15, 2),
(23, 11, 'Szaúd-arábiai Nagydíj', '2023-03-19', 2, 3),
(24, 6, 'Szaúd-arábiai Nagydíj', '2023-03-19', 3, 4),
(25, 5, 'Szaúd-arábiai Nagydíj', '2023-03-19', 7, 5),
(26, 4, 'Szaúd-arábiai Nagydíj', '2023-03-19', 4, 6),
(27, 3, 'Szaúd-arábiai Nagydíj', '2023-03-19', 12, 7),
(28, 8, 'Szaúd-arábiai Nagydíj', '2023-03-19', 6, 8),
(29, 7, 'Szaúd-arábiai Nagydíj', '2023-03-19', 9, 9),
(30, 15, 'Szaúd-arábiai Nagydíj', '2023-03-19', 8, 10),
(31, 18, 'Szaúd-arábiai Nagydíj', '2023-03-19', 16, 11),
(32, 16, 'Szaúd-arábiai Nagydíj', '2023-03-19', 10, 12),
(33, 14, 'Szaúd-arábiai Nagydíj', '2023-03-19', 11, 13),
(34, 17, 'Szaúd-arábiai Nagydíj', '2023-03-19', 18, 14),
(35, 10, 'Szaúd-arábiai Nagydíj', '2023-03-19', 20, 15),
(36, 19, 'Szaúd-arábiai Nagydíj', '2023-03-19', 19, 16),
(37, 13, 'Szaúd-arábiai Nagydíj', '2023-03-19', 14, 17),
(38, 20, 'Szaúd-arábiai Nagydíj', '2023-03-19', 17, 0),
(39, 12, 'Szaúd-arábiai Nagydíj', '2023-03-19', 5, 0),
(40, 9, 'Szaúd-arábiai Nagydíj', '2023-03-19', 13, 18),
(41, 1, 'Ausztrál Nagydíj', '2023-04-02', 1, 1),
(42, 5, 'Ausztrál Nagydíj', '2023-04-02', 3, 2),
(43, 11, 'Ausztrál Nagydíj', '2023-04-02', 4, 3),
(44, 6, 'Ausztrál Nagydíj', '2023-04-02', 6, 4),
(45, 2, 'Ausztrál Nagydíj', '2023-04-02', 2, 5),
(46, 4, 'Ausztrál Nagydíj', '2023-04-02', 5, 6),
(47, 3, 'Ausztrál Nagydíj', '2023-04-02', 7, 7),
(48, 8, 'Ausztrál Nagydíj', '2023-04-02', 8, 8),
(49, 7, 'Ausztrál Nagydíj', '2023-04-02', 9, 9),
(50, 15, 'Ausztrál Nagydíj', '2023-04-02', 10, 10),
(51, 18, 'Ausztrál Nagydíj', '2023-04-02', 11, 11),
(52, 16, 'Ausztrál Nagydíj', '2023-04-02', 12, 12),
(53, 14, 'Ausztrál Nagydíj', '2023-04-02', 13, 13),
(54, 17, 'Ausztrál Nagydíj', '2023-04-02', 14, 14),
(55, 10, 'Ausztrál Nagydíj', '2023-04-02', 15, 15),
(56, 19, 'Ausztrál Nagydíj', '2023-04-02', 16, 16),
(57, 13, 'Ausztrál Nagydíj', '2023-04-02', 17, 17),
(58, 20, 'Ausztrál Nagydíj', '2023-04-02', 18, 18),
(59, 12, 'Ausztrál Nagydíj', '2023-04-02', 19, 19),
(60, 9, 'Ausztrál Nagydíj', '2023-04-02', 20, 20),
(61, 2, 'Azerbajdzsáni Nagydíj', '2023-04-30', 3, 1),
(62, 1, 'Azerbajdzsáni Nagydíj', '2023-04-30', 2, 2),
(63, 3, 'Azerbajdzsáni Nagydíj', '2023-04-30', 1, 3),
(64, 11, 'Azerbajdzsáni Nagydíj', '2023-04-30', 6, 4),
(65, 4, 'Azerbajdzsáni Nagydíj', '2023-04-30', 5, 5),
(66, 5, 'Azerbajdzsáni Nagydíj', '2023-04-30', 7, 6),
(67, 12, 'Azerbajdzsáni Nagydíj', '2023-04-30', 8, 7),
(68, 6, 'Azerbajdzsáni Nagydíj', '2023-04-30', 9, 8),
(69, 9, 'Azerbajdzsáni Nagydíj', '2023-04-30', 10, 9),
(70, 18, 'Azerbajdzsáni Nagydíj', '2023-04-30', 11, 10),
(71, 10, 'Azerbajdzsáni Nagydíj', '2023-04-30', 12, 11),
(72, 20, 'Azerbajdzsáni Nagydíj', '2023-04-30', 13, 12),
(73, 15, 'Azerbajdzsáni Nagydíj', '2023-04-30', 14, 13),
(74, 8, 'Azerbajdzsáni Nagydíj', '2023-04-30', 15, 14),
(75, 19, 'Azerbajdzsáni Nagydíj', '2023-04-30', 16, 15),
(76, 13, 'Azerbajdzsáni Nagydíj', '2023-04-30', 17, 16),
(77, 17, 'Azerbajdzsáni Nagydíj', '2023-04-30', 18, 17),
(78, 14, 'Azerbajdzsáni Nagydíj', '2023-04-30', 19, 18),
(79, 7, 'Azerbajdzsáni Nagydíj', '2023-04-30', 20, 19),
(80, 16, 'Azerbajdzsáni Nagydíj', '2023-04-30', 21, 0),
(81, 1, 'Miami Nagydíj', '2023-05-07', 9, 1),
(82, 2, 'Miami Nagydíj', '2023-05-07', 1, 2),
(83, 11, 'Miami Nagydíj', '2023-05-07', 2, 3),
(84, 6, 'Miami Nagydíj', '2023-05-07', 6, 4),
(85, 4, 'Miami Nagydíj', '2023-05-07', 3, 5),
(86, 5, 'Miami Nagydíj', '2023-05-07', 13, 6),
(87, 3, 'Miami Nagydíj', '2023-05-07', 7, 7),
(88, 7, 'Miami Nagydíj', '2023-05-07', 10, 8),
(89, 8, 'Miami Nagydíj', '2023-05-07', 5, 9),
(90, 9, 'Miami Nagydíj', '2023-05-07', 11, 10),
(91, 15, 'Miami Nagydíj', '2023-05-07', 8, 11),
(92, 12, 'Miami Nagydíj', '2023-05-07', 18, 12),
(93, 13, 'Miami Nagydíj', '2023-05-07', 19, 13),
(94, 14, 'Miami Nagydíj', '2023-05-07', 16, 14),
(95, 18, 'Miami Nagydíj', '2023-05-07', 17, 15),
(96, 10, 'Miami Nagydíj', '2023-05-07', 20, 16),
(97, 16, 'Miami Nagydíj', '2023-05-07', 15, 17),
(98, 17, 'Miami Nagydíj', '2023-05-07', 12, 18),
(99, 20, 'Miami Nagydíj', '2023-05-07', 14, 19),
(100, 19, 'Miami Nagydíj', '2023-05-07', 4, 20);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pilotak`
--

CREATE TABLE `pilotak` (
  `pilotazonosito` int(11) NOT NULL,
  `pilotanev` varchar(100) DEFAULT NULL,
  `szerzodes_eve` int(11) DEFAULT NULL,
  `csapatazonosito` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

INSERT INTO `pilotak` (`pilotazonosito`, `pilotanev`, `szerzodes_eve`, `csapatazonosito`) VALUES
(1, 'Max Verstappen', 2016, 1),
(2, 'Sergio Perez', 2021, 1),
(3, 'Charles Leclerc', 2019, 2),
(4, 'Carlos Sainz', 2021, 2),
(5, 'Lewis Hamilton', 2013, 3),
(6, 'George Russell', 2019, 3),
(7, 'Pierre Gasly', 2023, 4),
(8, 'Esteban Ocon', 2020, 4),
(9, 'Lando Norris', 2019, 5),
(10, 'Oscar Piastri', 2023, 5),
(11, 'Fernando Alonso', 2021, 6),
(12, 'Lance Stroll', 2017, 6),
(13, 'Valtteri Bottas', 2022, 7),
(14, 'Zhou Guanyu', 2022, 7),
(15, 'Kevin Magnussen', 2022, 8),
(16, 'Nico Hülkenberg', 2023, 8),
(17, 'Nyck de Vries', 2023, 9),
(18, 'Yuki Tsunoda', 2021, 9),
(19, 'Logan Sargeant', 2023, 10),
(20, 'Alexander Albon', 2022, 10);


--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `csapatok`
--
ALTER TABLE `csapatok`
  ADD PRIMARY KEY (`csapatazonosito`);

--
-- A tábla indexei `eredmenyek`
--
ALTER TABLE `eredmenyek`
  ADD PRIMARY KEY (`nagydij_azonosito`),
  ADD KEY `pilotazonosito` (`pilotazonosito`);

--
-- A tábla indexei `pilotak`
--
ALTER TABLE `pilotak`
  ADD PRIMARY KEY (`pilotazonosito`),
  ADD KEY `csapatazonosito` (`csapatazonosito`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `csapatok`
--
ALTER TABLE `csapatok`
  MODIFY `csapatazonosito` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `eredmenyek`
--
ALTER TABLE `eredmenyek`
  MODIFY `nagydij_azonosito` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `pilotak`
--
ALTER TABLE `pilotak`
  MODIFY `pilotazonosito` int(11) NOT NULL AUTO_INCREMENT;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `eredmenyek`
--
ALTER TABLE `eredmenyek`
  ADD CONSTRAINT `eredmenyek_ibfk_1` FOREIGN KEY (`pilotazonosito`) REFERENCES `pilotak` (`pilotazonosito`);

--
-- Megkötések a táblához `pilotak`
--
ALTER TABLE `pilotak`
  ADD CONSTRAINT `pilotak_ibfk_1` FOREIGN KEY (`csapatazonosito`) REFERENCES `csapatok` (`csapatazonosito`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
