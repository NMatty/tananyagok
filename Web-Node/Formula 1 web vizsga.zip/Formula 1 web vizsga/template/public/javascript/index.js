document.addEventListener('DOMContentLoaded', () => {});

function setEqualHeight() {
    const pilotaBox = document.getElementById('pilota');
    const nagydijBox = document.getElementById('nagydij');

    if (window.innerWidth < 768) {
        pilotaBox.style.height = 'auto';
        nagydijBox.style.height = 'auto';
        return;
    }

    pilotaBox.style.height = 'auto';
    nagydijBox.style.height = 'auto';

    const pilotaHeight = pilotaBox.scrollHeight;
    const nagydijHeight = nagydijBox.scrollHeight;

    const newHeight = Math.min(400, Math.max(pilotaHeight, nagydijHeight));

    pilotaBox.style.height = newHeight + 'px';
    nagydijBox.style.height = newHeight + 'px';
}

const formatDate = (isoDate) => {
    const date = new Date(isoDate);
    return date.toLocaleDateString();
};

const selectPilotaRows = () => {
    const select = (tbody) => {
        for (const tr of tbody.children) {
            tr.addEventListener('click', function () {
                const item = this;
                console.log(item);
                if (item.dataset.selected === 'true') {
                    item.dataset.selected = 'false';
                    item.classList.remove('table-active');
                } else {
                    for (const tr of tbody.children) {
                        tr.dataset.selected = 'false';
                        tr.classList.remove('table-active');
                    }
                    item.dataset.selected = 'true';
                    item.classList.add('table-active');
                }
            });
        }
    };

    select(document.getElementById('pilotaBody'));
};

const selectNagydijRows = () => {
    const select = (tbody) => {
        for (const tr of tbody.children) {
            tr.addEventListener('click', function () {
                const item = this;
                console.log(item);
                if (item.dataset.selected === 'true') {
                    item.dataset.selected = 'false';
                    item.classList.remove('table-active');
                } else {
                    for (const tr of tbody.children) {
                        tr.dataset.selected = 'false';
                        tr.classList.remove('table-active');
                    }
                    item.dataset.selected = 'true';
                    item.classList.add('table-active');
                }
            });
        }
    };

    select(document.getElementById('nagydijBody'));
};

let chartInstance = null;

const createChart = (eredmenyek) => {
    const labels = eredmenyek.map((e) => e.nagydij_nev);
    const data = eredmenyek.map((e) => e.cel_pozicio);

    const ctx = document.getElementById('celPozicioChart').getContext('2d');

    if (chartInstance) {
        chartInstance.destroy();
    }

    chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Célpozíció',
                    data: data,
                    borderColor: 'blue',
                    backgroundColor: 'lightblue',
                    fill: false,
                    tension: 0.2
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Pilóta célpozíciói nagydíjak szerint'
                }
            },
            scales: {
                y: {
                    reverse: true,
                    title: {
                        display: true,
                        text: 'Célpozíció'
                    },
                    ticks: {
                        precision: 0,
                        stepSize: 1
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Nagydíj'
                    }
                }
            }
        }
    });
};
