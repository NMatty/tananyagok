document.addEventListener('DOMContentLoaded', function () {
    selectRow();
    document.getElementById('deleteFormFeladat').addEventListener('click', resetFeladatForm);
});

var myChart = null;

function selectRow() {
    let rs = (rows) => {
        rows.forEach((row) => {
            row.addEventListener('click', function () {
                // Először töröljük az összes kijelölést
                if (this.dataset.selected == 'true') {
                } else {
                    rows.forEach((row) => {});
                    // Majd hozzáadjuk a kiválasztott sorhoz a kijelölést
                }
            });
        });
    };
    rs(document.getElementById('projektBody').childNodes);
    rs(document.getElementById('feladatBody').childNodes);
}

function resetFeladatForm() {
    document.getElementById('feladatForm').reset();
}

function chartWrite(adatok) {
    if (myChart) {
        myChart.destroy();
    }
    var ctx = document.getElementById('myChart').getContext('2d');
    myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: adatok.feladat, // Az x tengely feliratai (feladat nevek)
            datasets: [
                {
                    label: 'Készültség', // A diagram címe
                    data: adatok.keszultseg, // Az y tengelyen megjelenítendő adatok (elkészültségi százalékok)
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true, // Az y tengely 0-tól induljon
                    max: 100 // Az y tengely maximális értéke legyen 100
                }
            }
        }
    });
}
