document.addEventListener('DOMContentLoaded', () => {
    selectTr();
});

const selectTr = () => {
    const tbody = document.querySelector('#varosBody');
    for (const tr of tbody.children) {
        tr.addEventListener('click', function () {
            const item = this;
            if (item.dataset.selected === 'true') {
                item.dataset.selected = 'false';
                item.classList.remove('table-active');
            } else {
                for (const tr of tbody.children) {
                    tr.dataset.selected = 'false';
                    tr.classList.remove('table-active');
                }
                item.dataset.selected = 'true';
                tr.classList.add('table-active');
            }
        });
    }
};
