-- Adatbázis használata
USE hajoadatok;

-- Táblázat létrehozása
CREATE TABLE hajok (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    nev VARCHAR(50),
    sebesseg INT, -- maximális sebesség
    szemelyzet INT, -- kapacitás
    gyartasi_ev INT,
    gyarto VARCHAR(50),
    active BOOLEAN
);

INSERT INTO hajok 
(nev, sebesseg, szemelyzet, gyartasi_ev, gyarto, active)
VALUES
('Queen Mary', 30, 120, 2004, 'Cunard Line', true),
('Titanic II', 25, 100, 2022, 'Harland and Wolff', true),
('Blue Marlin', 35, 80, 2000, 'Dockwise Shipping', true),
('Norwegian Breakaway', 28, 150, 2013, 'Meyer Werft', true),
('MSC Meraviglia', 32, 200, 2017, 'STX France', true),
('Harmony of the Seas', 27, 250, 2016, 'STX France', false),
('Oasis of the Seas', 33, 300, 2009, 'STX Europe', true),
('Symphony of the Seas', 29, 280, 2018, 'STX France', true),
('Carnival Horizon', 31, 210, 2018, 'Fincantieri', true),
('RMS Queen Elizabeth', 34, 110, 2010, 'Cunard Line', true),
('Norwegian Escape', 23, 170, 2015, 'Meyer Werft', false),
('Allure of the Seas', 37, 320, 2010, 'STX Europe', true),
('Anthem of the Seas', 24, 220, 2015, 'Meyer Werft', true),
('Ovation of the Seas', 36, 280, 2016, 'Meyer Werft', true),
('Celebrity Edge', 22, 200, 2018, 'Chantiers de l\'Atlantique', true),
('MSC Seaside', 38, 270, 2017, 'Fincantieri', true),
('Norwegian Joy', 21, 190, 2017, 'Meyer Werft', true),
('Carnival Vista', 39, 230, 2016, 'Fincantieri', true),
('Norwegian Bliss', 20, 180, 2018, 'Meyer Werft', true),
('Carnival Panorama', 40, 240, 2019, 'Fincantieri', true),
('MSC Bellissima', 19, 210, 2019, 'STX France', true),
('Carnival Mardi Gras', 41, 250, 2020, 'Meyer Turku', true),
('MSC Grandiosa', 18, 200, 2019, 'Chantiers de l\'Atlantique', true),
('Carnival Celebration', 42, 260, 2022, 'Meyer Turku', false),
('MSC Virtuosa', 17, 190, 2020, 'STX France', true),
('Carnival Radiance', 43, 270, 2020, 'Meyer Werft', true);