-- 
CREATE DATABASE autoberles 
DEFAULT CHARACTER set utf8
COLLATE utf8_hungarian_ci;

use autoberles;

CREATE TABLE berlok (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
    nev VARCHAR(100) NOT NULL, 
    jogositvanyszama VARCHAR(15) NOT NULL, 
    telefonszam VARCHAR(20) NULL
);

CREATE TABLE autok (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
    rendszam VARCHAR(6) NOT NULL UNIQUE, -- EGYEDI, ALTERNATÍV KULCS, 
    tipus VARCHAR(100) NOT NULL, 
    evjarat INT NULL, 
    szin VARCHAR(30) NULL
);

CREATE TABLE kolcsonzes (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT, 
    berloid INT NOT NULL, 
    autoid INT NOT NULL, 
    berletkezdete DATE NOT NULL, 
    napokszama INT NULL, 
    napidij INT NOT NULL,
	FOREIGN KEY (berloid) REFERENCES berlok(id),
    FOREIGN KEY (autoid) REFERENCES autok(id)
); 


INSERT INTO autok (rendszam, tipus, evjarat, szin) VALUES
('ABC456','Ford Ka', 2003, 'Pink'),
('ABC123','Volkswagen Golf', 2011, 'Fehér'),
('ABC157','Ford Mondeo', 2015, 'Fekete'),
('ABC448','Volkswagen Golf', 2012, 'Kék');

INSERT INTO berlok (nev, jogositvanyszama, telefonszam) VALUES
('Kandúr Károly', 'LR337157', '06-41-334112'),
('Gipsz Jakab', 'VE445112', '06-41-555223');


-- o	Kandúr Károly kikölcsönözte 2017. 04. 23-án az ABC157 rendszámú Ford Mondeót. A napi díj: 12 500 Ft. 

INSERT INTO kolcsonzes (berloid, autoid, berletkezdete, napidij, napokszama) VALUES
(
	(SELECT berlok.id FROM berlok WHERE berlok.nev LIKE 'Kandúr Károly'),
    (SELECT autok.id FROM autok WHERE autok.rendszam LIKE 'abc157'),
    '2017-04-23',
    12500,
    null
);

-- o	Gipsz Jakab 2017. 04. 25-én bérbe vette az ABC123 rendszámú Golfot, a napi díja: 9999 Ft. 
INSERT INTO kolcsonzes (berloid, autoid, berletkezdete, napidij, napokszama) VALUES
(
	(SELECT berlok.id FROM berlok WHERE berlok.nev LIKE 'Gipsz Jakab'),
    (SELECT autok.id FROM autok WHERE autok.rendszam LIKE 'abc123'),
    '2017-04-25',
    9999,
    null
);

-- o	Kandúr Károly visszahozta a nála lévő autót 2017. 04. 28-án, így összesen 6 napot volt nála. 
UPDATE kolcsonzes 
SET kolcsonzes.napokszama = 6
WHERE kolcsonzes.berloid = (SELECT berlok.id FROM berlok WHERE berlok.nev LIKE 'Kandúr Károly') AND 	
	kolcsonzes.autoid = (SELECT autok.id FROM autok WHERE autok.rendszam LIKE 'abc157');


-- o	Ami megadja az autók rendszámát, típusát, évjáratát, színét, a bérlés elejét és végét!

CREATE VIEW elso as (
	SELECT autok.rendszam, autok.tipus, autok.evjarat, autok.szin, kolcsonzes.berletkezdete, DATE_ADD(kolcsonzes.berletkezdete, INTERVAL kolcsonzes.napokszama day) as 'berletvege'
    FROM autok
    	INNER JOIN kolcsonzes ON (kolcsonzes.autoid = autok.id)
    WHERE kolcsonzes.napokszama is NOT null
);

